package com.pabloangelveliz.utn.androidinicial.converordetemperatura

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.pabloangelveliz.utn.androidinicial.converordetemperatura.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCalcular.setOnClickListener {

            if (binding.editTextValor.text.isEmpty()) {

                Toast.makeText(this, resources.getString(R.string.msg_validation), Toast.LENGTH_LONG).show()

            } else {

                val inputValue = java.lang.Float.parseFloat(
                    binding.editTextValor.text.toString())

                if (binding.radioButtonCelsius.isChecked) {
                    binding.editTextValor.setText(
                        convertFahrenheitToCelsius(inputValue).toString())
                }

                if(binding.radioButtonFahrenheit.isChecked) {
                    binding.editTextValor.setText(
                        convertCelsiusToFahrenheit(inputValue).toString())
                }

            }

        }

    }
}

// Convierte a Celsius
private fun convertFahrenheitToCelsius(fahrenheit: Float): Float = (fahrenheit - 32) * 5 / 9


// Convierte a Fahrenheit
private fun convertCelsiusToFahrenheit(celsius: Float): Float = celsius * 9 / 5 + 32
